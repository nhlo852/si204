#include <iostream>
#include <fstream>
using namespace std;

// ADD PROTOTYPE HERE



// DO NOT TOUCH THE MAIN FUNCTION
int main()
{
  cout << "Filename: ";
  string fname;
  cin >> fname;

  cout << avg(fname) << endl;
  return 0; 
}

// ADD DEFINITION HERE 

